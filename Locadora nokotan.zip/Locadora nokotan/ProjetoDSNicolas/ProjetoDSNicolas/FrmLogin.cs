﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoDSNicolas
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            string Login;
            MySqlDataReader reg = null;

            try
            {
                using (MySqlConnection conn = new MySqlConnection("server=localhost;database=bdlocadora;uid=root;pwd=''"))
                {
                    MySqlCommand comando = new MySqlCommand();
                    comando.Connection = conn;
                    comando.CommandText = "SELECT * FROM usuarios WHERE Login = @Email AND Senha = @senha";
                    comando.Parameters.AddWithValue("@Email", txtEmail.Text);
                    comando.Parameters.AddWithValue("@senha", txtSenha.Text);

                    conn.Open();
                    reg = comando.ExecuteReader();

                    if (reg.Read())
                    {
                        Login = reg["Login"].ToString();
                        MessageBox.Show("Acesso permitido! Usuário logado");
                        FrmMenu menu = new FrmMenu();
                        this.Hide();
                        menu.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Login/Usuário não conferem");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao tentar fazer login:\n" + ex.Message);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
        }
    

